<?php $__env->startSection('content'); ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Data SISWA SMK</h3>
            </div>
            <div class="panel-body">
                
                <table class="table table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>NIM</th>
                            
                            <th>Jurusan</th>
                            
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->nim); ?></td>
                           
                            <td><?php echo e($d->jurusan); ?></td>
                          
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud1\resources\views/index.blade.php ENDPATH**/ ?>