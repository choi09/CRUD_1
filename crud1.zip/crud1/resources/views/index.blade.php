@extends('layout.master')

@section('content')
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Data SISWA SMK</h3>
            </div>
            <div class="panel-body">
                
                <table class="table table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>NIM</th>
                            
                            <th>Jurusan</th>
                            
                        </tr>
                    </thead>

                    <tbody>
                        @foreach($data as $key => $d)
                        <tr>
                            <td>{{ $d->nim }}</td>
                           
                            <td>{{ $d->jurusan }}</td>
                          
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
@endsection
